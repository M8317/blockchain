// Charger les dépendances
var express = require('express');
var bodyParser = require('body-parser');
var router = express.Router();

var blockchain = require('./model/blockchain');
var network = require('./model/network');

blockchain.init();
network.init();

var app = express();
var server = require('http').createServer(app);
server.listen(3000, () => {
    console.log('🚀 Serveur démarré sur http://localhost:3000');
});

// Middleware pour parser le JSON
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// ✅ Route par défaut pour éviter "Cannot GET /"
router.get('/', function(req, res) {
    res.send('🚀 Serveur Blockchain en ligne !');
});

// ✅ Route pour obtenir la blockchain complète
router.get('/chain', function(req, res) {
    res.json({ chain: blockchain.getChain() });
});


// ✅ Route pour ajouter une transaction
router.post('/transactions', function(req, res) {
    var sender = req.body.sender;
    var receiver = req.body.receiver;
    var amount = req.body.amount;

    if (!sender || !receiver || amount === undefined || isNaN(amount)) {
        return res.status(400).json({ error: "Invalid transaction data" });
    }

    let transaction = blockchain.newTransaction(sender, receiver, parseFloat(amount));
    res.json({ message: "✅ Transaction ajoutée avec succès", transaction });
});

// ✅ Route pour miner un bloc (⚠️ Vérifie bien que cette route est avant `app.use('/', router)`)
router.post('/mine', function(req, res) {
    var miningNode = req.headers.host;

    if (!network.nodeExists(miningNode)) {
        network.registerNode(miningNode);
    }

    let newBlock = blockchain.mine(miningNode);

    res.json({
        message: "⛏️ Bloc miné avec succès",
        block: newBlock
    });
});

// ✅ Route pour vérifier la validité de la blockchain
router.get('/checkChain', function(req, res) {
    res.json({
        valid: blockchain.checkChain().length > 0,
        chain: blockchain.getChain()
    });
});

// ✅ Route pour obtenir tous les nœuds
router.get('/nodes', function(req, res) {
    res.json({ nodes: network.getNodes() });
});

// ✅ Route pour enregistrer un nœud
router.post('/nodes/register', function(req, res) {
    res.json({ message: "Nœud enregistré", success: network.registerNode(req.headers.host) });
});

// Correction de l'ordre des routes : Assurez-vous que TOUTES LES ROUTES sont définies AVANT d'utiliser `app.use(router);`
app.use('/', router);

//Middleware pour gérer les routes inexistantes
app.use(function(req, res, next) {
    res.status(404).json({ error: "Route not found" });
});

// Middleware pour gérer les erreurs serveur
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    console.log("🚨 Erreur serveur : ", err.message);
    res.json({ error: err.message });
});

module.exports = app;
