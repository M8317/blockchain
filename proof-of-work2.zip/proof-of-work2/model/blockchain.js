var addressUtilities = require('../utils/address');
var arrayUtilities = require('../utils/array');
var validator = require('../utils/validator');

var blockchain = function blockchain(){

  var self = this;

  this.init = init;
  this.newBlock = newBlock;
  this.newTransaction = newTransaction;
  this.getChain = getChain;
  this.checkChain = checkChain;
  this.mine = mine;

  this.chain;
  this.currentTransactions;

  function init(){
    /*
    *  initialize the blockchain, creating a new empty chain,
    *  an empty transactions list and creating the first block
    */
    self.chain = [];
    self.currentTransactions = [];
    self.newBlock(100, 1);
  }

  function getChain(){
    /*
    *  returns the chain
    */
    return self.chain;
  }

  function mine(miner) {
    var lastBlock = self.chain[self.chain.length - 1];
    var transaction = newTransaction(0, miner, 1);
    var proof = validator.generateProof(transaction);

    // ✅ Correction : Supprimer `previousHash` avant de hasher
    let lastBlockCopy = { ...lastBlock };  // Copie propre du dernier bloc
    delete lastBlockCopy.previousHash;     // On supprime `previousHash` avant de hasher

    var previousHash = validator.calculateHash(lastBlockCopy);  // On hash la copie nettoyée

    return newBlock(proof, previousHash);
  }



  function newBlock(proof, previousHash){
    /*
    *  Generate a new blocks and adds it to the chain
    */
    var block = {
      "index": self.chain.length+1,
      "timestamp": new Date().getTime(),
      "transaction": self.currentTransactions,
      "proof": proof,
      "previousHash": previousHash
    }
    self.currentTransactions = [];
    self.chain.push(block);
    return block;
  }

  function newTransaction(sender, receiver, amount){
    /*
    *  Generate a new transaction
    */
    var transaction = {
      sender: sender,
      receiver: receiver,
      amount: amount
    };
    self.currentTransactions.push(transaction);
    return transaction;
  }

  function checkChain() {
    /*
    * Vérifie si la chaîne de blocs est valide
    * Retourne la chaîne si elle est valide, sinon retourne []
    */

    if (!self.chain || self.chain.length === 0) {
      return [];
    }

    for (var i = 1; i < self.chain.length; i++) {
      var currentBlock = self.chain[i];
      var previousBlock = self.chain[i - 1];

      // Vérification de l'intégrité des indices
      if (currentBlock.index !== previousBlock.index + 1) {
        return [];
      }

      // Vérification du hash précédent
      var calculatedPreviousHash = validator.calculateHash(JSON.stringify(previousBlock));
      if (currentBlock.previousHash !== calculatedPreviousHash) {
        return [];
      }


      // Vérification de la preuve de travail
      var validProof = validator.generateProof(currentBlock.transaction[0]);
      if (currentBlock.proof !== validProof) {
        return [];
      }

      // Vérification de la structure du bloc
      if (!currentBlock.index || !currentBlock.timestamp || !currentBlock.transaction ||
          !currentBlock.proof || !currentBlock.previousHash) {
        return [];
      }
    }

    return self.chain;
  }



  if(blockchain.caller != blockchain.getInstance){
    throw new Error("This object cannot be instanciated");
  }

};


blockchain.instance = null;
blockchain.getInstance = function(){
	if(this.instance === null){
		this.instance = new blockchain();
	}
	return this.instance;
};

module.exports = blockchain.getInstance();
