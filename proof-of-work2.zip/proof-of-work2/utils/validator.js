var ValidatorHandler = function ValidatorHandler() {

  var self = this;

  this.calculateHash = calculateHash;
  this.generateProof = generateProof;

  /**
   * ✅ Corrigé : Génère un hash pour un bloc entier
   */
  function calculateHash(block) {
    if (!block || typeof block !== 'object') {
      return false;
    }
    let blockString = JSON.stringify(block);
    return generateHashFromString(blockString);
  }

  /**
   * ✅ Génère une preuve de travail
   */
  function generateProof(transaction) {
    if (!transaction || transaction.sender === undefined || transaction.receiver === undefined || transaction.amount === undefined) {
      return false;
    }
    if (transaction.sender === 0) {
      return generateIntegerFromAddress(transaction.receiver) * parseFloat(transaction.amount);
    }
    return Math.abs(generateIntegerFromAddress(transaction.sender) - generateIntegerFromAddress(transaction.receiver)) * parseFloat(transaction.amount);
  }

  /**
   * ✅ Fonction pour générer un hash à partir d'une chaîne de caractères
   */
  function generateHashFromString(string) {
    var hex, i;
    var result = "";
    for (i = 0; i < string.length; i++) {
      hex = string.charCodeAt(i).toString(16);
      result += ("0" + hex).slice(-4);
    }
    return result;
  }

  /**
   * ✅ Convertit une adresse en un entier pour la preuve de travail
   */
  function generateIntegerFromAddress(address) {
    let numbers = address.match(/[0-9]+/g);
    return numbers ? parseInt(numbers.join("")) : 0;
  }

  if (ValidatorHandler.caller != ValidatorHandler.getInstance) {
    throw new Error("This object cannot be instantiated");
  }

};

ValidatorHandler.instance = null;
ValidatorHandler.getInstance = function() {
  if (this.instance === null) {
    this.instance = new ValidatorHandler();
  }
  return this.instance;
};

module.exports = ValidatorHandler.getInstance();
